package metier;


public class Tache {
    private int id;
    private String description;
    private String priorite;
    private String etat;

    public Tache(int id, String description, String priorite, String etat) {
        this.id = id;
        this.description = description;
        this.priorite = priorite;
        this.etat = etat;
    }

    public String toString() {
        return "ID: " + id + ", Description: " + description + ", Priorité: " + priorite + ", État: " + etat;
    }
}