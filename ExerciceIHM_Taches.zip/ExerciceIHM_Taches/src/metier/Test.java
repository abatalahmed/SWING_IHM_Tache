package metier;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;


public class Test extends JFrame {
	
	
	
    private ArrayList<Tache> taches;
    
    private JList<Tache> listeTaches;
    
    
    private DefaultListModel<Tache> modeleListe;
    
    
    private JTextField champDescription;
    private JComboBox<String> comboPriorite;
    private JComboBox<String> comboEtat;
    
    private int compteurId;

    public Test() {
    	
        this.setTitle("Gestionnaire de Tâches");
        taches = new ArrayList<>();
        modeleListe = new DefaultListModel<>();
        listeTaches = new JList<>(modeleListe);
        compteurId = 1;

        champDescription = new JTextField(20);
        comboPriorite = new JComboBox();
        comboPriorite.addItem("Haute");
        comboPriorite.addItem("Moyenne");
        comboPriorite.addItem("Basse");
         
        comboEtat = new JComboBox<>(new String[]{"À faire", "En cours", "Terminée"});
        JButton boutonAjouter = new JButton("Ajouter");
        JButton boutonEffacer = new JButton("Effacer");

        boutonAjouter.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ajouterTache();
            }
        });

        boutonEffacer.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                effacerTache();
            }
        });

        JPanel panneauForm = new JPanel();
        panneauForm.add(new JLabel("Description:"));
        panneauForm.add(champDescription);
        panneauForm.add(new JLabel("Priorité:"));
        panneauForm.add(comboPriorite);
        panneauForm.add(new JLabel("État:"));
        panneauForm.add(comboEtat);
        panneauForm.add(boutonAjouter);
        panneauForm.add(boutonEffacer);

        setLayout(new BorderLayout());
        add(panneauForm, BorderLayout.NORTH);
        add(new JScrollPane(listeTaches), BorderLayout.CENTER);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 300);
        setVisible(true);
    }

    private void ajouterTache() {
        Tache nouvelleTache = new Tache(compteurId++, champDescription.getText(), (String) comboPriorite.getSelectedItem(), (String) comboEtat.getSelectedItem());
        taches.add(nouvelleTache);
        modeleListe.addElement(nouvelleTache);
        champDescription.setText("");
        comboPriorite.setSelectedIndex(0);
        comboEtat.setSelectedIndex(0);
    }

    private void effacerTache() {
        int index = listeTaches.getSelectedIndex();
        if (index != -1) {
            taches.remove(index);
            modeleListe.remove(index);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Test();
            }
        });
    }
}
